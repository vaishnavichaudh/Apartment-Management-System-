<?php
session_start();

// Debugging: Display raw POST data (Remove this in production)
echo "<pre>";
print_r($_POST);
echo "</pre>";

// Mock user database (Replace with real database in production)
$users = [
    ['email' => 'admin@example.com', 'password' => 'admin123', 'role' => 'admin'],
    ['email' => 'user@example.com', 'password' => 'user123', 'role' => 'user']
];

// Capture form inputs
$email = isset($_POST['email']) ? $_POST['email'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$role = isset($_POST['role']) ? $_POST['role'] : '';

// Debugging: Display captured inputs
echo "Email: $email<br>";
echo "Password: $password<br>";
echo "Role: $role<br>";

// Validate credentials
$loginSuccessful = false;
foreach ($users as $user) {
    if ($user['email'] === $email && $user['password'] === $password && $user['role'] === $role) {
        $_SESSION['role'] = $role;
        $_SESSION['email'] = $email;
        $loginSuccessful = true;

        // Debugging: Display success message
        echo "Login successful! Redirecting to the $role panel...<br>";

        // Redirect based on role
        if ($role === 'admin') {
            header("Location: admin.html");
            exit();
        } elseif ($role === 'user') {
            header("Location: user_dashboard.html");
            exit();
        }
    }
}

// If login fails
if (!$loginSuccessful) {
    echo "Invalid credentials. Please try again.<br>";
    echo "<a href='login.html'>Go Back to Login Page</a>";
}
?>
