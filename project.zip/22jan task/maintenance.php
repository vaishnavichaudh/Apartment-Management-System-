<?php
// Include the database connection
include 'db_connection.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['maintenance-title'];
    $description = $_POST['maintenance-description'];
    $type = $_POST['maintenance-type'];
    $request_date = $_POST['maintenance-request-date'];
    $status = $_POST['maintenance-status'];

    // Prepare an SQL statement to insert the data
    $sql = "INSERT INTO maintenance(title, description, type, request_date, status)
            VALUES (?, ?, ?, ?, ?)";

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $title, $description, $type, $request_date, $status);

    if ($stmt->execute()) {
        echo "Maintenance request added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}

include 'db_connection.php';

// SQL query to fetch all data from the apartments table
$sql = "SELECT * FROM maintenance";
$result = $conn->query($sql);
echo "<h1>Maintence Request</h1>";
if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='10' cellspacing='0'>";
    echo "<tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Type</th>
            <th>Request_Date</th>
            <th>Status</th>
          </tr>";

    // Loop through each record and display it in a table row
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['id'] . "</td>
                <td>" . $row['Title'] . "</td>
                <td>" . $row['description'] . "</td>
                <td>" . $row['type'] . "</td>
                <td>" . $row['request_date'] . "</td>
                <td>" . $row['status'] . "</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No records found.";
}

$conn->close();

?>
