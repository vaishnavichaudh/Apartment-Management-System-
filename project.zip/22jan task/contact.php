<?php
// Include the database connection file
include('db_connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
   $message = $_POST['message'];
   

    // Prepare and bind SQL statement
   echo  $sql = "INSERT INTO contact(name,email,message) VALUES ('".$name."','".$email."','".$message."')";
   $res = mysqli_query($conn,$sql); 
  
    if ($res) {
        echo "Message sent successfully! <script> alert('Send Successful!');
             window.location.href = 'home.html';</script>";
    } else {
        echo "Error: Something Wrong" ;
    }
    

    // Close statement and connection   
    $conn->close();
}

?>
