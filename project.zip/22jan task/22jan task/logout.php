<?php
session_start(); // Start the session

// Destroy all session data
session_unset(); 
session_destroy();

// Redirect to the homepage or login page after logging out
header("Location: ../home.html"); // Or replace with the appropriate redirect URL
exit();
?>
