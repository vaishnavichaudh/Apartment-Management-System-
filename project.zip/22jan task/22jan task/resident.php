<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = $_POST['resident-name'];
    $dob = $_POST['resident-dob'];
    $gender = $_POST['resident-gender'];
    $emergencyName = $_POST['resident-emergency-name'];
    $emergencyPhone = $_POST['resident-emergency-phone'];
    $occupation = $_POST['resident-occupation'];
    $nationality = $_POST['resident-nationality'];
    $email = $_POST['resident-email'];
    $photoPath = "";

    // Handle file upload
    if (isset($_FILES['resident-photo']) && $_FILES['resident-photo']['error'] == 0) {
        $targetDir = "uploads/";
        $photoPath = $targetDir . basename($_FILES['resident-photo']['name']);
        move_uploaded_file($_FILES['resident-photo']['tmp_name'], $photoPath);
    }

    // Insert or update query
    $sql = "INSERT INTO residents (full_name, date_of_birth, gender, emergency_contact_name, emergency_contact_phone, occupation, nationality, email, photo_path)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
            full_name = VALUES(full_name), date_of_birth = VALUES(date_of_birth), gender = VALUES(gender),
            emergency_contact_name = VALUES(emergency_contact_name), emergency_contact_phone = VALUES(emergency_contact_phone),
            occupation = VALUES(occupation), nationality = VALUES(nationality), photo_path = VALUES(photo_path)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssss", $fullName, $dob, $gender, $emergencyName, $emergencyPhone, $occupation, $nationality, $email, $photoPath);

    if ($stmt->execute()) {
        echo "Resident data saved successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
