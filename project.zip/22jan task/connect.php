<?php

$servername="localhost";
$username="root";
$password="";
$dbname="livinghub";

//create connection
$conn=new mysqli($servername,$username,$password,$dbname);

//check connection
if($conn->connect_error){
    echo "Failed to connect to DB".$conn->connection_error;
}