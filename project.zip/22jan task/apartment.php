<?php
session_start();


include 'db_connection.php'; // Include the database connection script
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$full_name = isset($_POST['full_name']) ? $_POST['full_name'] : '';
$flat_number = isset($_POST['flat_number']) ? $_POST['flat_number'] : '';
$flat_type = isset($_POST['flat_type']) ? $_POST['flat_type'] : '';
$flat_price = isset($_POST['flat_price']) ? $_POST['flat_price'] : '';
$flat_status = isset($_POST['flat-status']) ? $_POST['flat-status'] : '';

echo "Flat Status: $flat_status";
// Now use these variables in the SQL query
 echo $sql = "INSERT INTO apartments(full_name, flat_number, flat_type, flat_price, flat_status) 
        VALUES('".$full_name."','".$flat_number."','".$flat_type."','".$flat_price."','".$flat_status."')";

 $res = mysqli_query($conn,$sql);
    if ($res) {
        echo "Message sent successfully!";
    } else {
        echo "Error: Something Wrong" ;
    }
    

    // Close statement and connection  
$conn->close();
}


include 'db_connection.php';

// SQL query to fetch all data from the apartments table
$sql = "SELECT * FROM apartments";
$result = $conn->query($sql);
echo "<h1>Apartment Data</h1>";
if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='10' cellspacing='0'>";
    echo "<tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Flat Number</th>
            <th>Flat Type</th>
            <th>Flat Price</th>
            <th>Flat Status</th>
          </tr>";

    // Loop through each record and display it in a table row
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['id'] . "</td>
                <td>" . $row['full_name'] . "</td>
                <td>" . $row['flat_number'] . "</td>
                <td>" . $row['flat_type'] . "</td>
                <td>" . $row['flat_price'] . "</td>
                <td>" . $row['flat_status'] . "</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No records found.";
}

$conn->close();


?>
