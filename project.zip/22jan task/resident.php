<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = $_POST['resident-name'];
    $dob = $_POST['resident-dob'];
    $gender = $_POST['resident-gender'];
    $emergencyName = $_POST['resident-emergency-name'];
    $emergencyPhone = $_POST['resident-emergency-phone'];
    $occupation = $_POST['resident-occupation'];
    $nationality = $_POST['resident-nationality'];
    $email = $_POST['resident-email'];
    $photoPath = "";

    // Handle file upload
    if (isset($_FILES['resident-photo']) && $_FILES['resident-photo']['error'] == 0) {
        $targetDir = "uploads/";
        $photoPath = $targetDir . basename($_FILES['resident-photo']['name']);
        move_uploaded_file($_FILES['resident-photo']['tmp_name'], $photoPath);
    }

    
  
   // $stmt = $conn->prepare($sql);
  //  $stmt->bind_param("sssssssss", $fullName, $dob, $gender, $emergencyName, $emergencyPhone, $occupation, $nationality, $email, $photoPath);


echo  $sql = "INSERT INTO residents(full_name, date_of_birth, gender, emergency_contact_name, emergency_contact_phone, occupation, nationality, email, photo_path) 
VALUES ('".$full_name."','".$date_of_birth."','".$gender."','".$emergency_contact_name."','".$emergency_contact_phone."','".$occupation."','".$nationality."','".$photo_path."')";
  
$res = mysqli_query($conn,$sql);

if ($res) {
    echo "Registration successful! <a href='signup.html'><br>Sign Up Here</a>";
} else {
    echo "Error: Something Wrong" ;
}
$conn->close();
}
?>
