<?php
// Include the database connection file
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $residentName = $_POST['payment-resident'];
    $amount = $_POST['payment-amount'];
    $method = $_POST['payment-method'];
    $reference = $_POST['payment-reference'];
    $date = $_POST['payment-date'];
    $status = $_POST['payment-status'];

    // Insert the data into the payments table
    try {
        $sql = "INSERT INTO payment(resident_name, amount, payment_method, reference_number, payment_date, payment_status)
                VALUES (:resident_name, :amount, :method, :reference, :payment_date, :status)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':resident_name', $residentName);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':method', $method);
        $stmt->bindParam(':reference', $reference);
        $stmt->bindParam(':payment_date', $date);
        $stmt->bindParam(':status', $status);

        $stmt->execute();
        echo "Payment successfully recorded.";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid request method.";
}
?>
