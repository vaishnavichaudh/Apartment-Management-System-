<?php
session_start();

// Check if the user is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    // If not, redirect to login page
    header('Location: login.php');
    exit();
}
?>

<h1>Welcome to the Admin Panel</h1>
<!-- Admin functionalities go here -->
