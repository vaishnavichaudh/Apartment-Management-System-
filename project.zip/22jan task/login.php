
<?php
include('db_connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
//  Retrieve login form data
$email = $_POST['email'];
$password = $_POST['password'];
$role = $_POST['role'];
  

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    echo  $sql = "INSERT INTO user_login(email,password,role) VALUES ('".$email."','".$password."','".$role."')";
  
    $res = mysqli_query($conn,$sql);

    if ($res) {
        echo "Registration successful! <script> alert('Registration Successful!');
        window.location.href = 'admin.html';</script>";
    } else {
        echo "Error: Something Wrong" ;
    }
$conn->close();
}
?>





