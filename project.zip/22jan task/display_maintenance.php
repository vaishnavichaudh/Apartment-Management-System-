<?php
/*include 'db_connection.php';

// SQL query to fetch all data from the apartments table
$sql = "SELECT * FROM maintenance";
$result = $conn->query($sql);
echo "<h1>Maintence Request</h1>";
if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='10' cellspacing='0'>";
    echo "<tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Type</th>
            <th>Request_Date</th>
            <th>Status</th>
          </tr>";

    // Loop through each record and display it in a table row
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['id'] . "</td>
                <td>" . $row['Title'] . "</td>
                <td>" . $row['description'] . "</td>
                <td>" . $row['type'] . "</td>
                <td>" . $row['request_date'] . "</td>
                <td>" . $row['status'] . "</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No records found.";
}

$conn->close();
?>*/
