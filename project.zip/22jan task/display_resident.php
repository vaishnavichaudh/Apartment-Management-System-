<?php
/*include 'db_connection.php';

// SQL query to fetch all data from the apartments table
$sql = "SELECT * FROM residents";
$result = $conn->query($sql);
echo "<h1>Resident Data</h1>";
if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='10' cellspacing='0'>";
    echo "<tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>DOB</th>
            <th>Gender</th>
            <th>Emergency-Name</th>
            <th>Emergency-Phone</th>
            <th>Occupation</th>
            <th>Nationality</th>
            <th>Email</th>
            <th>Photo</th>
          </tr>";

    // Loop through each record and display it in a table row
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['int'] . "</td>
                <td>" . $row['full_name'] . "</td>
                <td>" . $row['date_of_birth'] . "</td>
                <td>" . $row['gender'] . "</td>
                <td>" . $row['emergency_contact_name'] . "</td>
                <td>" . $row['emergency_contact_phone'] . "</td>
                <td>" . $row['occupation'] . "</td>
                <td>" . $row['nationality'] . "</td>
                <td>" . $row['email'] . "</td>
                <td>" . $row['photo_path'] . "</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No records found.";
}

$conn->close();
?>*/
