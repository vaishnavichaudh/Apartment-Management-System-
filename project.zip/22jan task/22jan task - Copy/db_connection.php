<?php
$host = 'localhost'; // Database server (e.g., localhost)
$user = 'root';      // Database username
$password = '';      // Database password
$database = 'livinghub'; // Database name

// Create connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>
