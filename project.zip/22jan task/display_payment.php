<?php
/*include 'db_connection.php';

// SQL query to fetch all data from the apartments table
$sql = "SELECT * FROM payment";
$result = $conn->query($sql);
echo "<h1>Payment Data</h1>";
if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='10' cellspacing='0'>";
    echo "<tr>
            <th>ID</th>
            <th>payment-resident</th>
            <th>payment-amount</th>
            <th>payment-method</th>
            <th>payment_reference</th>
            <th>payment-date</th>
              <th>payment-status</th>
               
          </tr>";

    // Loop through each record and display it in a table row
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                      <td>" . $row['id'] . "</td>
        <td>" . $row['resident_name'] . "</td> <!-- Changed to correct column name -->
        <td>" . $row['amount'] . "</td>
        <td>" . $row['payment_method'] . "</td> <!-- Changed to correct column name -->
        <td>" . $row['payment_reference'] . "</td> <!-- Changed to correct column name -->
        <td>" . $row['payment_date'] . "</td> <!-- Changed to correct column name -->
        <td>" . $row['payment_status'] . "</td> <!-- Changed to correct column name -->
     
       
              </tr>";
    }
    echo "</table>";
} else {
    echo "No records found.";
}

$conn->close();
?>*/


