<?php
// Include the database connection
include 'db_connection.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $reporter_name = $_POST['reporter-name'];
    $report_title = $_POST['report-title'];
    $report_type = $_POST['report-type'];
    $incident_date = $_POST['report-date'];
    $reporter_contact = $_POST['reporter-contact'];
    $description = $_POST['report-description'];
    $status = $_POST['report-status'];

    // Prepare the SQL query
    $sql = "INSERT INTO report(reporter_name, report_title, report_type, incident_date, reporter_contact, description, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    // Use a prepared statement to prevent SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $reporter_name, $report_title, $report_type, $incident_date, $reporter_contact, $description, $status);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Report submitted successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}

// Include the database connection
include 'db_connection.php';

// Fetch all reports from the database
$sql = "SELECT * FROM report";
$result = $conn->query($sql);

// Display the reports
if ($result->num_rows > 0) {
    echo "<h2>Submitted Reports</h2>";
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Reporter Name</th>
                <th>Title</th>
                <th>Type</th>
                <th>Incident Date</th>
                <th>Contact</th>
                <th>Description</th>
                <th>Status</th>
            </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['reporter_name']}</td>
                <td>{$row['report_title']}</td>
                <td>{$row['report_type']}</td>
                <td>{$row['incident_date']}</td>
                <td>{$row['reporter_contact']}</td>
                <td>{$row['description']}</td>
                <td>{$row['status']}</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No reports found.";
}

// Close the connection
$conn->close();

?>
