<?php
include 'db_connection.php'; // Include the connection script

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $firstName = $_POST['FirstName'];
    $lastName = $_POST['LastName'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $password = $_POST['password'];

    // Hash the password for security
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

  echo  $sql = "INSERT INTO signup (first_name, last_name, email, gender, password) VALUES ('".$firstName."','".$lastName."','".$email."','".$gender."','".$hashedPassword."')";
    $res = mysqli_query($conn,$sql);

    if ($res) {
        echo "Registration successful! <a href='login.html'>Login here</a>";
    } else {
        echo "Error: Something Wrong" ;
    }
    $conn->close();
}
?>
